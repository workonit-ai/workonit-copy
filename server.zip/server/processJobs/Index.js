const {handlecomingtweets} = require('../OauthConnections/TwitterJob')
const Log = require('../utilities/Log')
const config = require('../config')
const runTwitter = () => {
    Log.server('Twitter job is running')
    try{
        setInterval(() => {
            handlecomingtweets()
        }, config.twitter.Social_post_time);
    }catch(err){
        Log.error('Twitter job error', err)
    }
    
}
const runJobs = async () => {
    runTwitter()
    
}
module.exports = {runJobs}