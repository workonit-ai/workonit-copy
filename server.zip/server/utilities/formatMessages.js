const formatMessage = (message) => {
    return {
        _id: message.id,
        isPrompt: message.role === 'user',
        inboxId: message.thread_id,
        messageContent: message.content[0].text.value,
        timestamp: message.created_at
    };
}


// Sort the messages based on the timestamp and then return it
const formatMessages = (messages) => {
    return messages.map((message) => formatMessage(message))
                   .sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
};

module.exports = {
    formatMessage,
    formatMessages
}
