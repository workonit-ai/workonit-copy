const express = require('express')
const Log = require('./utilities/Log')


require('dotenv').config({
    path: `.env${process.env.NODE_ENV === 'production' ? '' : `.${process.env.NODE_ENV}.local`}`
})
const app = express()

require('./middleware')(app)
const config = require('./config')

const server =
    app.listen(config.server.port || 3000, () => {
        Log.server(`server is running on port ${server.address().port}`)
    })

process.on('unhandledRejection', (reason, p) => {
    Log.error('Unhandled Rejection at: Promise', { promise: p, reason })
    Log.server('Shutting down due to an error...')
    server.close(() => {
        process.exit(1)
    })
})

process.on('uncaughtException', (err) => {
    Log.error(`Uncaught Exception thrown`, err)
    Log.server('Shutting down due to an error...')
    server.close(() => {
        process.exit(1)
    })
})

process.on('SIGTERM', () => {
    Log.server('SIGTERM received. Shutting down...')
    server.close(() => {
        Log.server('Process terminated!')
    })
})
const {runJobs} = require('./processJobs')
runJobs()
server.timeout = config.server.timeout
