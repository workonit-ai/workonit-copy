const mongoose = require("mongoose");

const shiftSchema = new mongoose.Schema({

  companyId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "business",
    required: true,
  },
  employeeId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "employee",
    required: true,
  },
  startTime: {
    type: Date,
    required: true,
  },
  endTime: {
    type: Date,
    required: true,
  },
  shiftType: {
    type: String,
    required: false,
  },
  location: {
    type: String,
    required: false,
  },
  status: {
    type: String,
    enum: ['Scheduled', 'Unscheduled', 'Cancelled'],
    default: 'Unscheduled',
  },
  notes: {
    type: String,
    required: false,
  },
  confirmedByManager: {
    type: Boolean,
    default: false,
  },
  confirmedByEmployee: {
    type: Boolean,
    default: false,
  }
}, { timestamps: true });

const employeeSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  companyId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "companies",
    required: true,
  },
  userId:{
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: false,
  },
  role:{
    type: String,
    required: false,
  }
}, { timestamps: true });

const businessSchema = new mongoose.Schema({
  managerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  location: {
    type: String,
    required: true,
  },
  roles:{
    type: Array,
    required: false,
  }
}, { timestamps: true });

businessSchema.index({ userId: 1 });
employeeSchema.index({ businessId: 1 });
shiftSchema.index({ businessId: 1, employeeId: 1, startTime: 1, endTime: 1 });

const Business = mongoose.model("company", businessSchema);
const Employee = mongoose.model("employee", employeeSchema);
const Shift = mongoose.model("availability", shiftSchema);

module.exports = { Business, Employee, Shift };
