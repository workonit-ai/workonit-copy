const mongoose = require("mongoose");

const weeklyScheduleSchema = new mongoose.Schema({
  companyId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "business",
    required: true,
  },
  employeeId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "employee",
    required: true,
  },
  weekStartDate: {
    type: Date,
    required: true,
  },
  shifts: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: "shift"
  }],
  status: {
    type: String,
    enum: ['Pending', 'Submitted', 'Approved', 'Rejected'],
    default: 'Pending',
  },
  notes: {
    type: String,
  }
}, { timestamps: true });

weeklyScheduleSchema.index({ companyId: 1, employeeId: 1, weekStartDate: 1 });

const WeeklySchedule = mongoose.model("weeklySchedule", weeklyScheduleSchema);

module.exports = { WeeklySchedule };