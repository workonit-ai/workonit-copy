const { WeeklySchedule } = require('../../models/WeeklySchedule');
const { Employee } = require('../../models/Business');
const { Shift } = require('../../models/Business');
const { Business } = require('../../models/Business');
const Log = require('../../utilities/Log');
const mongoose = require('mongoose');
const { getUserInbox } = require('../utils/getUserInbox');
const Assistant = require('../Assistant');
const { sendEmail } = require('../../utilities/sendgrid');
const config = require('../../config');
const cron = require('node-cron');
const openai = require('../utils/openaiInstance');


// const OpenAI = require('openai');
// const openai = new OpenAI({
//     apiKey: config.openAI.key
// }).beta;

exports.initiate_weekly_scheduling = async (args) => {
    const { businessId, weekStartDate, checkInterval } = args;

    if (!businessId || !weekStartDate || !checkInterval) {
        return {
            success: false,
            message: 'businessId, weekStartDate, and checkInterval are required'
        };
    }

    // Validate checkTime format
    if (!/^([01]\d|2[0-3]):([0-5]\d)$/.test(checkInterval)) {
        return {
            success: false,
            message:
                'Invalid checkInterval format. Please use HH:00 in 24-hour format.'
        };
    }

    try {
        const businessObjectId = new mongoose.Types.ObjectId(businessId);
        const employees = await Employee.find({ companyId: businessObjectId });

        if (employees.length === 0) {
            Log.info(`No employees found for business ${businessId}`);
            return {
                status: 'success',
                message: 'No employees found for this business'
            };
        }

        const weeklySchedules = await Promise.all(
            employees.map(async (employee) => {
                return await WeeklySchedule.create({
                    companyId: businessId,
                    employeeId: employee._id,
                    weekStartDate: new Date(weekStartDate),
                    status: 'Pending'
                });
            })
        );

        Log.info(
            `Created ${weeklySchedules.length} weekly schedules for business ${businessId}`
        );

        // Trigger the post-scheduling tasks asynchronously
        await this.scheduleAutomatedCheckins(
            businessId,
            weekStartDate,
            checkInterval
        );
        setImmediate(() =>
            this.processPostSchedulingTasks(weeklySchedules, employees)
        );

        return {
            status: 'success',
            message: `Initiated scheduling for ${weeklySchedules.length} employees.`,
            data: {
                weekStartDate,
                employeesScheduled: weeklySchedules.length
            }
        };
    } catch (error) {
        Log.error('Error in initiate_weekly_scheduling:', error);
        return {
            status: 'error',
            message: 'Failed to initiate weekly scheduling',
            error: error.message
        };
    }
};

exports.processPostSchedulingTasks = async (weeklySchedules, employees) => {
    try {
        for (let i = 0; i < employees.length; i++) {
            const employee = employees[i];
            const schedule = weeklySchedules[i];

            await sendEmail(
                'Weekly Schedule Initiated',
                `Your weekly schedule for the week starting ${schedule.weekStartDate} has been initiated. Please submit your availability.`,
                `<p>Your weekly schedule for the week starting ${schedule.weekStartDate} has been initiated. Please submit your availability.</p>`,
                employee.email
            );
            if (employee.userId) {
                const inbox = await getUserInbox(employee.userId);
                if (inbox) {
                    Log.info(
                        `Adding message to inbox for employee ${employee._id}`
                    );
                    await openai.threads.messages.create(inbox.threadId, {
                        role: 'assistant',
                        content: `Your weekly schedule for the week starting ${schedule.weekStartDate} has been initiated. Please submit your availability.`
                    });
                } else {
                    Log.warn(`No inbox found for employee ${employee._id}`);
                }
            } else {
                Log.warn(`No userId found for employee ${employee._id}`);
            }
        }
        Log.info('Completed post-scheduling tasks');
    } catch (error) {
        Log.error('Error in processPostSchedulingTasks:', error);
    }
};

exports.submit_employee_shifts = async (args) => {
    const { employeeId, weekStartDate, shifts } = args;

    if (!employeeId || !weekStartDate || !shifts || !Array.isArray(shifts)) {
        throw new Error(
            'employeeId, weekStartDate, and shifts array are required'
        );
    }

    console.log('Week startDate is', weekStartDate);
    console.log('Date(weekStartDate)', new Date(weekStartDate));

    try {
        // Find the weekly schedule for the employee
        const weeklySchedule = await WeeklySchedule.findOne({
            employeeId,
            weekStartDate: new Date(weekStartDate)
        });

        if (!weeklySchedule) {
            return {
                status: 'error',
                message: 'Weekly schedule not found for the employee and week'
            };
        }

        // Create shift documents and add them to the weekly schedule
        const createdShifts = await Promise.all(
            shifts.map(async (shiftData) => {
                const newShift = new Shift({
                    weeklyScheduleId: weeklySchedule._id,
                    companyId: weeklySchedule.companyId,
                    employeeId,
                    startTime: new Date(shiftData.startTime),
                    endTime: new Date(shiftData.endTime),
                    notes: shiftData.notes || ''
                });
                await newShift.save();
                return newShift;
            })
        );

        // Update the weekly schedule with the new shifts
        weeklySchedule.shifts = createdShifts.map((shift) => shift._id);
        weeklySchedule.status = 'Submitted';
        await weeklySchedule.save();

        Log.info(
            `Submitted ${createdShifts.length} shifts for employee ${employeeId} for week starting ${weekStartDate}`
        );

        return {
            status: 'success',
            message: `Submitted ${createdShifts.length} shifts for the week.`,
            data: {
                weekStartDate,
                shiftsSubmitted: createdShifts.length
            }
        };
    } catch (error) {
        Log.error('Error in submit_employee_shifts:', error);
        return {
            status: 'error',
            message: 'Failed to submit employee shifts',
            error: error.message
        };
    }
};

exports.scheduleAutomatedCheckins = async (
    businessId,
    weekStartDate,
    checkInterval
) => {
    Log.info(
        `Scheduling checks for business ${businessId} every ${checkInterval} starting from ${weekStartDate}`
    );
    try {
        const business = await Business.findById(businessId);
        if (!business) {
            Log.error(`Business not found with ID: ${businessId}`);
            throw new Error('Business not found');
        }

        Log.info(`Business found: ${business.name}`);
        const weekStart = new Date(weekStartDate);
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekEnd.getDate() + 7);

        Log.info(
            `Week start: ${weekStart.toISOString()}, Week end: ${weekEnd.toISOString()}`
        );

        const [hours, minutes] = checkInterval.split(':').map(Number);
        const intervalMinutes = hours * 60 + minutes;
        Log.info(
            `Check interval: ${checkInterval}, Converted to ${intervalMinutes} minutes`
        );
        // Convert interval to cron expression
        const cronExpression = `*/${intervalMinutes} * * * *`;
        Log.info(`Cron expression: ${cronExpression}`);

        // cron.schedule(cronExpression, async () => {
        //     const now = new Date();
        //     if (now >= weekStart && now < weekEnd) {
        //         await performCheck(businessId, weekStartDate);
        //     } else if (now >= weekEnd) {
        //         // Stop the cron job after the week ends
        //         this.stop();
        //     }
        // }, {
        //     scheduled: true,
        //     // timezone: business.timezone // Assuming business has a timezone field
        // });
        const job = cron.schedule(
            cronExpression,
            async () => {
                Log.info(`Cron job triggered at ${new Date().toISOString()}`);
                const now = new Date();
                // if (now >= weekStart && now < weekEnd) {
                //     Log.info(`Performing check for business ${businessId}`);
                //     await performCheck(businessId, weekStartDate);
                // } else if (now >= weekEnd) {
                //     Log.info(
                //         `Week has ended. Stopping cron job for business ${businessId}`
                //     );
                //     job.stop();
                // } else {
                //     Log.info(
                //         `Current time ${now.toISOString()} is before week start. Skipping check.`
                //     );
                // }
                if (now <= weekStart) {
                    Log.info(`Performing check for business ${businessId}`);
                    await performCheck(businessId, weekStartDate);
                } else if (now >= weekEnd) {
                    Log.info(
                        `Week has ended. Stopping cron job for business ${businessId}`
                    );
                    job.stop();
                } else {
                    Log.info(
                        `Current time ${now.toISOString()} is before week start. Skipping check.`
                    );
                }
            },
            {
                scheduled: true
                // timezone: business.timezone // Uncomment if you have a timezone field
            }
        );

        Log.info(`Cron job scheduled successfully for business ${businessId}`);

        Log.info(
            `Scheduled checks for business ${businessId} every ${checkInterval}, starting from ${weekStart.toLocaleString()}`
        );
    } catch (error) {
        Log.error(`Error in scheduleAutomatedCheckins: ${error.message}`);
        throw error;
    }
};

async function performCheck(businessId, weekStartDate) {
    Log.info(`Performing check for business ${businessId}`);
    try {
    const weeklySchedules = await WeeklySchedule.find({
        companyId: businessId,
        weekStartDate: new Date(weekStartDate),
        status: { $ne: 'Completed' }
    }).populate('employeeId');

    Log.info(`Found ${weeklySchedules.length} non-completed weekly schedules`);

    let allSubmitted = true;
    const managerNotifications = [];

    for (const schedule of weeklySchedules) {
        if (schedule.status !== 'Submitted') {
            allSubmitted = false;
            Log.info(`Sending reminder to employee ${schedule.employeeId._id}`);


            await sendReminderToEmployee(schedule.employeeId, weekStartDate);
            managerNotifications.push(
                `${schedule.employeeId.name} has not submitted their availability yet.`
            );
        }
    }

    if (allSubmitted) {
        Log.info(`All employees have submitted their availability for business ${businessId}`);
        await notifyManager(
            businessId,
            weekStartDate,
            'All employees have submitted their availability.'
        );
    } else {
        Log.info(`Not all employees have submitted their availability for business ${businessId}`);
        await notifyManager(
            businessId,
            weekStartDate,
            managerNotifications.join('\n')
        );
    }
} catch (error) {
    Log.error(`Error in performCheck: ${error.message}`);
}
}

if (require.main === module) {
    const inputJson = {
        userID: '669bd7728f993d87c5fa6c47',
        assistantName: 'SIMA_Test',
        threadID: 'thread_0M2RIIixcj9w3JU8EGC7h4J8',
        companyId: '66ac9f0876935ffd356ad59e',
        weekStartDate: '2024-08-05'
    };

    exports
        .initiate_weekly_scheduling(inputJson)
        .then((result) => Log.info(result))
        .catch((error) => Log.error(error));
}

async function sendReminderToEmployee(employee, weekStartDate) {
    const reminderMessage = `Reminder: Please submit your availability for the week starting ${weekStartDate}.`;

    // Send email
    await sendEmail(
        'Availability Submission Reminder',
        reminderMessage,
        `<p>${reminderMessage}</p>`,
        employee.email
    );

    // Send in-app notification
    const inbox = await getUserInbox(employee.userId);
    if (inbox) {
        await Assistant.createAssistantMessage(reminderMessage, inbox.threadId);
    }

    Log.info(`Sent reminder to employee ${employee._id}`);
}

async function notifyManager(businessId, weekStartDate, message) {
    const business = await Business.findById(businessId);
    const manager = await User.findById(business.created_on_behalf_of_user);
    const managerMessage = `Everyone has set up their availabilities for the week starting on: ${weekStartDate}:\n${message}`;

    // Send email to manager
    await sendEmail(
        'Weekly Scheduling Update',
        managerMessage,
        `<p>${managerMessage}</p>`,
        manager.email
    );

    // Send in-app notification to manager
    const managerInbox = await getUserInbox(business.created_on_behalf_of_user);
    if (managerInbox) {
        await Assistant.createAssistantMessage(
            managerMessage,
            managerInbox.threadId
        );
    }

    Log.info(
        `Notified manager of business ${businessId} about scheduling status`
    );
}
