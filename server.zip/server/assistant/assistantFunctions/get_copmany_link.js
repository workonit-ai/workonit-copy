
const Business = require('../../models/Business');
const Log = require('../../utilities/Log');

exports.get_copmany_link = async (companyName) => {
    if (typeof companyName === 'object' && companyName !== null && companyName.hasOwnProperty('companyName')) {
        companyName = companyName.companyName;
    }
    
    
    Log.info(`Searching for business: ${companyName}`);
    const business = await Business.findOne({ businessName: companyName });
    Log.info(`Business found: ${business}`);
    if (!business) {
        return 'Business not found';
    }
    return `www.workonit.ai/sima/${encodeURIComponent(business._id)}/${encodeURIComponent(business.businessName)}`;
}


