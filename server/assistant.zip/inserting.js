const config = require('./config')
const db_read = require('./assistant/assistantFunctions/db_read')
db_read