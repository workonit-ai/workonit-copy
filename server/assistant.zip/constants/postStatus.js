module.exports = {
    CREATED: 'Created',
    PHRASED: 'Phrased',
    TIMED: 'Timed',
    PAID: 'Paid',
    PENDING: 'Pending',
    FAILED: 'Failed',
    POSTED: 'Posted',
    COMPLETED: 'Completed'
}
